module.exports = app => {
    const reg = require("../controllers/reg.controller.js");
    var router = require("express").Router();

    router.post("/", reg.create);

    router.get("/", reg.findAll);

    router.delete("/:_id", reg.delete);

    app.use('/api/reg', router);
};