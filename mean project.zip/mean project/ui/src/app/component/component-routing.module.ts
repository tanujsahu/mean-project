import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ButtonsComponent } from './buttons/buttons.component';
import { ComponentComponent } from './component.component';
import { DailogComponent } from './dailog/dailog.component';

const routes: Routes = [
  {
    path: '', component: ComponentComponent
  },
  { path: 'dailog', component: DailogComponent },
  { path: 'buttons', component: ButtonsComponent },

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ComponentRouting { }



// import { NgModule } from '@angular/core';
// import { Routes, RouterModule } from '@angular/router';
// import { ContactComponent } from './contact/contact.component';

// const routes: Routes = [
//   {
//     path: '',
//     component: ContactComponent
//   }
// ];

// @NgModule({
//   imports: [RouterModule.forChild(routes)],
//   exports: [RouterModule]
// })
// export class NewRouting { }