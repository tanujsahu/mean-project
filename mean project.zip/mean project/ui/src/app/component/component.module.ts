import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DailogComponent } from './dailog/dailog.component';
import { ComponentComponent } from './component.component';
import { ComponentRouting } from './component-routing.module';
import { MatCardModule } from '@angular/material/card';
import { MatDialogModule } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { FlexLayoutModule } from '@angular/flex-layout';
import { ButtonsComponent } from './buttons/buttons.component';
import { MatIconModule } from '@angular/material/icon';
import { MatDividerModule } from '@angular/material/divider';
@NgModule({
  declarations: [
    DailogComponent,
    ComponentComponent,
    ButtonsComponent
  ],
  imports: [
    CommonModule, ComponentRouting, MatCardModule, MatDialogModule, MatButtonModule, FlexLayoutModule, MatIconModule, MatDividerModule
  ]
})
export class ComponentModule { }
