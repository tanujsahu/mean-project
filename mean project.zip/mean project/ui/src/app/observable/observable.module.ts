import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ObservableComponent } from './observable/observable.component';
import { ObservableRouting } from './observable-routing.module';

@NgModule({
  declarations: [
    ObservableComponent
  ],
  imports: [
    CommonModule,ObservableRouting
  ]
})
export class ObservableModule { }
