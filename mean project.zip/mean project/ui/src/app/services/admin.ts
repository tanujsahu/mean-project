export class IReg {
    name?: String;
    emailId?: String;
    mobile?: String;
    age?: String;
    address?: String;
}