import { Injectable } from '@angular/core';
import { HttpService } from '../commonfiles/http.service';
@Injectable({
  providedIn: 'root'
})
export class RegService {

  constructor(private http: HttpService) { }

  //--------------------------------------------- Get All Users
  getAll() {
    return this.http.get('reg');
  }

  //------------------------------------------------ Save
  save(data: any) {
    console.log("user data:)", data)
    return this.http.post('reg', data);
  }

  //------------------------------------------------ Delete
  delete(_id: any) {
    return this.http.delete('reg/' + _id);
  }

  
}
