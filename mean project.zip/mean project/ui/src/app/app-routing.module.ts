import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { NotFoundComponent } from './not-found/not-found.component';

const routes: Routes = [
  {
    path: '', component: HomeComponent
  },
  {
    path: 'items',
    loadChildren: () => import('./../app/newmodule/newmodule.module').then(m => m.NewmoduleModule)
  },
  {
    path: 'promise',
    loadChildren: () => import('./../app/promise/promise.module').then(m => m.PromiseModule)
  },
  {
    path: 'observable',
    loadChildren: () => import('./../app/observable/observable.module').then(m => m.ObservableModule)
  },
  {
    path: 'components',
    loadChildren: () => import('./../app/component/component.module').then(m => m.ComponentModule)
  },
  {
    path: 'users',
    loadChildren: () => import('./../app/users/users.module').then(m => m.UsersModule)
  },
  {
    path: '**', component: NotFoundComponent
  }
];
@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true })],
  exports: [RouterModule]
  //   const routes: Routes = [
  //     { path: 'first-component', component: FirstComponent },
  //     { path: 'second-component', component: SecondComponent },
  //   ];
})
export class AppRoutingModule { }
