import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RegComponent } from './reg/reg.component';

const routes: Routes = [
  {
    path: '', component: RegComponent,
  },
  {
    path: 'reg', component: RegComponent,
  },
  {
    path: 'reg', component: RegComponent,
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UsersRouting { }



// import { NgModule } from '@angular/core';
// import { Routes, RouterModule } from '@angular/router';
// import { ContactComponent } from './contact/contact.component';

// const routes: Routes = [
//   {
//     path: '',
//     component: ContactComponent
//   }
// ];

// @NgModule({
//   imports: [RouterModule.forChild(routes)],
//   exports: [RouterModule]
// })
// export class NewRouting { }