import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RegComponent } from './reg/reg.component';
import { UsersRouting } from './reg-routing.module';
import { MatInputModule } from '@angular/material/input';
import { ReactiveFormsModule } from '@angular/forms';
import { GetUsersComponent } from './get-users/get-users.component';
@NgModule({
  declarations: [
    RegComponent,
    GetUsersComponent
  ],
  imports: [
    CommonModule, UsersRouting, MatInputModule, ReactiveFormsModule
  ]
})

export class UsersModule { }
