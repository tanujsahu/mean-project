import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder } from '@angular/forms';
import { RegService } from 'src/app/services/reg.service';
@Component({
  selector: 'app-reg',
  templateUrl: './reg.component.html',
  styleUrls: ['./reg.component.css']
})
export class RegComponent implements OnInit {
  profileForm = this.fb.group({
    name: [''],
    mobile: [''],
  });
  constructor(private fb: FormBuilder, private regService: RegService) { }
  // private regService: RegService
  ngOnInit(): void {

  }

  save() {
    console.log(this.profileForm.value,this.profileForm);
    // this.regService.save(this.profileForm.value).then(obj => {
    //   console.log("saved Succesfully:) !!");
    // }, error => {
    //   console.log("Error:", error);
    //   alert("Error:" + error.message);
    // })
  }
}
