import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent implements OnInit {

  constructor() { }
  contact = "Contact Component";

  ngOnInit(): void {
  }

  btn_show: boolean = false; name = "";
  clickhere() {
    this.btn_show ? this.btn_show = false : this.btn_show = true;
    //  alert(`hello alert ${this.name}`);
    console.log(this.btn_show)

  }
}
