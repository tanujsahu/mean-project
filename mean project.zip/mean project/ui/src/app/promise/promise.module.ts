import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PromiseComponent } from './promise/promise.component';
import { PromiseRouting } from './promise-routing.module';
import { MatButtonModule } from '@angular/material/button';

@NgModule({
  declarations: [
    PromiseComponent
  ],
  imports: [
    CommonModule, PromiseRouting, MatButtonModule,
  ],
  exports: [
    MatButtonModule
  ],
})

export class PromiseModule { }
