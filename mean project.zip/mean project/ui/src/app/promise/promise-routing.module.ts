import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PromiseComponent } from './promise/promise.component';

const routes: Routes = [
  {
    path: '', component: PromiseComponent,
  },
  {
    path: 'promise', component: PromiseComponent
  },
  {
    path: 'observable', component: PromiseComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PromiseRouting { }



// import { NgModule } from '@angular/core';
// import { Routes, RouterModule } from '@angular/router';
// import { ContactComponent } from './contact/contact.component';

// const routes: Routes = [
//   {
//     path: '',
//     component: ContactComponent
//   }
// ];

// @NgModule({
//   imports: [RouterModule.forChild(routes)],
//   exports: [RouterModule]
// })
// export class NewRouting { }