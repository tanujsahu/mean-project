import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-promise',
  templateUrl: './promise.component.html',
  styleUrls: ['./promise.component.css']
})
export class PromiseComponent implements OnInit {

  constructor() { }
  dell() {
    return false;
  }
  hp() {
    return true;
  }
  
  ngOnInit(): void {
    let buyLaptop = new Promise((resolve, reject) => {
      if (this.dell()) {
        resolve("Dell Available");
        alert("Dell Is Available")
      }
      else if (this.hp()) {
        resolve("HP Available");
        alert("HP Is Available")
      }
      else {
        reject("Laptop Is Not Available");
        alert("Laptop Is Not Available")

      }
    });
    buyLaptop.then(res => {
      console.log("succes:", res)
    })
  }

  myFunction() {
    console.log("my Function Called");
  }

}
