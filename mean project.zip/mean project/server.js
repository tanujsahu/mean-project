var express = require('express');
//var log = require('morgan')('dev');
var bodyParser = require('body-parser');
var config = require('./config');
const numCPUs = 1// require('os').cpus().length;
var app = express();
const useragent = require('express-useragent');
app.use(useragent.express());
app.use(express.static(__dirname + '/ui/dist'));
app.use(express.static(__dirname + '/files'));
app.use(express.static(__dirname + '/ui/src/environments'));
const cluster = require('cluster');
var bodyParserJSON = bodyParser.json({ limit: '50mb' });
var bodyParserURLEncoded = bodyParser.urlencoded({ limit: '50mb', extended: true });
app.use(bodyParserJSON);
app.use(bodyParserURLEncoded);

var cors = require('cors');

app.use(cors());
// app.use(function (req, res, next) {
//     // Website you wish to allow to connect
//     res.setHeader('Access-Control-Allow-Origin', '*');

//     // Request methods you wish to allow
//     res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');

//     // Request headers you wish to allow
//     res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');

//     res.setHeader('Access-Control-Allow-Credentials', true);

//     // Pass to next layer of middleware
//     next();
// });



//------------------------------------------------------------------ use express router
app.get('/', function (req, res) {
    res.redirect('/index.html');
});

require("./routes/reg.route.js")(app);

if (cluster.isMaster) {
    console.log(`Master O ${process.pid} is running`);
    // Fork workers.
    for (let i = 0; i < numCPUs; i++) {
        cluster.fork();
    }
    cluster.on('exit', (worker, code, signal) => {
        console.log(`worker ${worker.process.pid} died`);
        cluster.fork(); //------------------------------------------------------------- Create a New Worker, If Worker is Dead
    });
} else {
    app.listen(config.serverPort, config.host, function () {
        console.log("Express server listening on port " + config.serverPort + " as Worker " + cluster.worker.id + " running @ process " + cluster.worker.process.pid + "!");
    });
}

// app.post('/acceptStreaming', function (req, res) {
//     var file = myBucket.file('test5.mp4');
//     var writeOutstream = fs.createWriteStream('text1.mp4');
//     req.pipe(writeOutstream({
//         metadata: {
//             contentType: 'video/mp4',
//             metadata: {
//                 custom: 'metadata'
//             }
//         }
//     }
//     )).on('error', function (err) {
//         console.log("Error:-", err)
//     })
//         .on('finish', function () {
//             res.send("finish")
//             // The file upload is complete.
//         });
// });

module.exports = app;