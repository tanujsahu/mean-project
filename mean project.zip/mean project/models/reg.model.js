const { stringify } = require("querystring");

module.exports = mongoose => {
    const Reg = mongoose.model(
        "reg",
        mongoose.Schema(
            {
                name: String,
                emailId: String,
                mobile: String,
                age: String,
                address: String,
            },
            { timestamps: true }
        )
    );
    return Reg;
};