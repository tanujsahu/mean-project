const db = require("../models");
const { format } = require("path");
const mongoose = require("mongoose");
// const config = require('../config.js');
// const msg = require(`../lang/${config.lang}.json`);
const Reg = db.Reg;

const nodemailer = require('nodemailer');
const Mail = require("nodemailer/lib/mailer");

exports.create = (req, res) => {
    console.log("Body:", req.body)
    if (!req.body.name) {
        return res.status(400).send({ message: "User Name Can't be empty!" });
    }
    if (req.body._id) {
        Reg.findOne({ emailId: req.body.emailId, _id: { $ne: req.body._id } }).then(Reg => {
            if (Reg) {
                return res.status(500).send({ message: `EmailId '${req.body.emailId}' already in Use!` });
            }
            Reg.findByIdAndUpdate({ _id: req.body._id }, req.body)
                .then(data => {
                    res.send({ message: `emailId ' ${req.body.emailId}' Updated successfully!` });
                })
                .catch(err => {
                    res.status(500).send({
                        message:
                            err.message || "Data Not Found !!"
                    });
                });
        });
    } else {
        // Reg.findOne({ mobile: req.body.mobile }).then(reg => {
        //     if (reg) {
        //         return res.status(500).send({ message: `mobile '${req.body.mobile}' already exists!` });
        //     }
        console.log("req body:) ", req.body);
        const RegObj = new Reg({
            name: req.body.name,
            emailId: req.body.emailId,
            mobile: req.body.mobile,
            age: req.body.age,
            address: req.body.address,
        });
        RegObj.save()
            .then(data => {
                res.send(data);
            })
            .catch(err => {
                res.status(500).send({
                    message:
                        err.message || "Data Not Found !!"
                });
            });
        // });
    }

};

//------------------------------------------------------------------ get all users list 
exports.findAll = (req, res) => {
    Reg.find().then(data => {
        res.send(data);
    }).catch(err => {
        res.status(500).send({
            message:
                err.message || "Data Not Found !!"
        });
    });
};

//------------------------------------------------------------------- Delete
exports.delete = (req, res) => {
    Reg.deleteOne({ _id: req.params._id }).then(data => {
        res.send(data);
    }).catch(err => {
        res.status(500).send({
            message:
                err.message || "Data Not Found !!"
        });
    });
};

exports.Mail = (req, res) => {
    let mailTransporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
            user: 'tanujdots@gmail.com',
            pass: 'Tanuj@Dots54'
        }
    });

    let mailDetails = {
        from: 'tanujdots@gmail.com',
        to: 'tanujsahu09@gmail.com',
        subject: 'Test mail',
        text: 'Node.js testing mail for GeeksforGeeks'
    };

    mailTransporter.sendMail(mailDetails, function (err, data) {
        if (err) {
            console.log('Error Occurs');
        } else {
            console.log('Email sent successfully');
        }
    });
}
//-----------------
let mailTransporter = nodemailer.createTransport({
    service: 'gmail',
    host: "smtp.ethereal.email",
    port: 587,
    secure: false,
    auth: {
        user: 'tanujdots@gmail.com',
        pass: 'Tanuj@Dots54'
    }
});

let mailDetails = {
    from: 'tanujdots@gmail.com',
    to: 'tanujsahu09@gmail.com',
    subject: 'Test mail',
    text: 'Node.js testing mail for GeeksforGeeks',
    html: "<b>Hello world?</b> <i>Tanuj Sahu Here<i>", // html body
};

mailTransporter.sendMail(mailDetails, function (err, data) {
    if (err) {
        console.log('Error Occurs');
    } else {
        console.log('Email sent successfully');
    }
});